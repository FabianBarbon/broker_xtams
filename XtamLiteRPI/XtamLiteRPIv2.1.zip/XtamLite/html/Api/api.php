﻿<?php

$url = "http://localhost/NOC/xml.php?plugin=complete&json";

$data = file_get_contents("/var/www/html/XtamLite-UI/configuration.json"); 
$xtamConfig = json_decode($data, true);
$ipserver = $xtamConfig["ipXtamRemoto"];

$json = file_get_contents($url);
$obj = json_decode($json, true);

foreach ($obj['Generation'] as $ob) {
    $timestamp = $ob['timestamp'];
}

foreach ($obj['MBInfo']['Temperature']['Item'] as $ob) {
    $temperature = $ob['Value'];
}

$host = new stdClass();
foreach ($obj['Vitals'] as $ob) {
    $namepc = $ob['Hostname'];
    $ip = $ob['IPAddr'];
    $host = array("Host" => $namepc, "Ip" => $ipserver);
}


$memory = new stdClass();
foreach ($obj['Memory'] as $key => $ob) {
    if (is_array($ob)) {
        if ($key == '@attributes') {
            $mlibre = $ob['Free'];
            $mlusada = $ob['Used'];
            $mtotal = $ob['Total'];
            $mporcentaje = $ob['Percent'];
            $memory = array("Libre" => $mlibre, "Usada" => $mlusada, "Total" => $mtotal, "Porcent" => $mporcentaje);
        }
    }
}

$disco = new stdClass();

foreach ($obj['FileSystem']['Mount'] as $key => $ob) {

    $did =  $ob['MountPointID'];
    $type = $ob['FSType'];
    $dname = $ob['Name'];
    $dtotal = $ob['Total'];
    $dusado = $ob['Used'];
    $dlibre = $ob['Free'];
    $dprocentaje = $ob['Percent'];
    $dmontaje = $ob['MountPoint'];

    $disco->$did = array("ID" => $did,  "FSType" => $type,  "Name" => $dname, "Total" => $dtotal, "Used" => $dusado, "Free" => $dlibre, "Percent" => $dprocentaje, "MountPoint" => $dmontaje);
}

$cpu = new stdClass();
$id = 0;
foreach ($obj['Hardware']['CPU']['CpuCore'] as $key => $ob) {
    $cpumodel = $ob['@attributes']['Model'];
    $cpuCpuSpeed = $ob['@attributes']['CpuSpeed'];
    $cpucache = $ob['@attributes']['Cache'];
    $cpuLoad = $ob['@attributes']['Load'];

    $cpu->$id = array('Model' => $cpumodel, 'CpuSpeed' => $cpuCpuSpeed, 'Cache' => $cpucache, 'Load' => $cpuLoad);
    $id++;
}

$plugin = new stdClass();
$p = 0;
foreach ($obj["Plugins"]['Plugin_PSStatus']['Process'] as $key => $ob) {
    $pluginname =   $ob['@attributes']['Name'];
    $pluginstate = $ob['@attributes']['Status'];
    $plugin->$p = array('Name' => $pluginname, 'Status' => $pluginstate);
    $p++;
}

$envio = new stdClass();
$envio->xtam = $host;
$envio->time = $timestamp;
$envio->temperature = $temperature;
$envio->memoria =  $memory;
$envio->disco = $disco;
$envio->cpu = $cpu;
$envio->plugin = $plugin;
$datos = json_encode($envio);
//echo print_r($datos);

if (file_exists('/var/www/html/Api/old.json')) {
    $data = fopen("/var/www/html/Api/new.json", "r");
    $file1 = '/var/www/html/Api/new.json';
    file_put_contents($file1, $datos);

    $jsonnew = file_get_contents('/var/www/html/Api/new.json');
    $compare1 = json_decode($jsonnew, true);

    $jsonold = file_get_contents('/var/www/html/Api/old.json');
    $compare2 = json_decode($jsonold, true);

    json_post($datos);

} else {

    $data = fopen("/var/www/html/Api/old.json", "r");
    $file1 = '/var/www/html/Api/old.json';
    file_put_contents($file1, $datos);

    json_post($datos);
}

function json_post($datos)
{

    echo print_r($datos);
    $data = file_get_contents("/var/www/html/XtamLite-UI/configuration.json"); 

    $xtamConfig = json_decode($data, true);

    $ipcentral = $xtamConfig["ipXtamCentral"];

  
    //$url = 'http://'.$ipcentral.'/xtamvideo/public/admin/noc';
    $url = 'http://'.$ipcentral.':3000/api/noc/update/';
    echo print_r($url);

    $ch = curl_init($url);

    curl_setopt_array($ch, array(
        // Indicar que vamos a hacer una petición POST
        CURLOPT_CUSTOMREQUEST => "POST",
        // Justo aquí ponemos los datos dentro del cuerpo
        CURLOPT_POSTFIELDS => $datos,
        // Encabezados
        //CURLOPT_HEADER => true,
        CURLOPT_HTTPHEADER => array(
            'Content-Type: application/json',
            'Content-Length: ' . strlen($datos), // Abajo podríamos agregar más encabezados            
        ),
        # indicar que regrese los datos, no que los imprima directamente
        CURLOPT_RETURNTRANSFER => true,
    ));

    # Hora de hacer la petición
    $resultado = curl_exec($ch);
    # Vemos si el código es 200, es decir, HTTP_OK
    $codigoRespuesta = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    if ($codigoRespuesta === 200) {
        # Decodificar JSON porque esa es la respuesta
        $responsejson = json_decode($resultado);
        echo print_r($responsejson);
    } else {
        # Error
        echo "Error consultando. Código de respuesta: $codigoRespuesta";
    }
    curl_close($ch);
}
