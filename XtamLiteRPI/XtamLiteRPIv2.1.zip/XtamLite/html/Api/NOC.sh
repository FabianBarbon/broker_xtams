#!/bin/bash
sudo php /var/www/html/Api/api.php
exit