#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Mar  6 21:42:40 2022

@author: pi
"""
import json , time ,datetime
import os
import logging #log
import sys #control de errores
import requests

ipXtamCentral = '1.47.5.155'
ipXtamRemote  = '192.168.0.25'
count_alert_cpu = 0
count_alert_temp = 0
count_alert_robustel = 0
count_alert_disk = 0
formatter = logging.Formatter('%(asctime)s %(levelname)s %(message)s')
jsonData  = ''

def setup_logger(name, log_file, level=logging.INFO):
    
    handler = logging.FileHandler(log_file)        
    handler.setFormatter(formatter)

    logger = logging.getLogger(name)
    logger.setLevel(level)
    logger.addHandler(handler)

    return logger

def check_File_Exist(filePath):
    try:
        with open(filePath, 'r') as f:
            return True
    except FileNotFoundError as e:
        return False
    except IOError as e:
        return False
    
def init_config():
    try:
        global ipXtamCentral
        global ipXtamRemote
        print('inicia configuración')
        with open('/var/www/html/XtamLite-UI/configuration.json') as file:
            data = json.load(file)
            ipXtamCentral = data['ipXtamCentral']
            ipXtamRemote  = data['ipXtamRemoto']
    except:
        logger.error('error actualizando los datos NOC :'+str(e)) 
        
##########################################################################    
dir_logGEN = '/var/www/html/Api/Monitor/Log/General_logfile.log'
###Se valida tamano maximo para no saturar la raspberry
filesize_log = 0
filesize_log = os.path.getsize(dir_logGEN)
filesize_log = (filesize_log / 1024) / 1024  #se calcula tamano en Megas
if filesize_log > 10:
    os.remove(dir_logGEN)
#########################################################################    
dir_logWar = '/var/www/html/Api/Monitor/Log/Warnings_Log.log'
###Se valida tamano maximo para no saturar la raspberry
filesize_logWar = 0
filesize_logWar = os.path.getsize(dir_logWar)
filesize_logWar = (filesize_logWar / 1024) / 1024  #se calcula tamano en Megas
if filesize_logWar > 10:
    os.remove(dir_logWar)
###########################################################################
# first file logger
logger = setup_logger('general_logger', dir_logGEN)
loggerWarning = setup_logger('warning_logger', dir_logWar)
loggerWarning.info('Arranco Xtam')
logger.info('Iniciando NOC MONITOR v1.0...')
logger.info('Configurando...')
timeToSend = 0
time.sleep(2)
# iniciar configuración
init_config()

def send_average_consumption():
    try:
        global ipXtamCentral
        with open('/var/www/html/Api/Monitor/average_consuption.json') as file:
            data_set = json.load(file)
            url = "http://"+ipXtamCentral+":3000/api/noc/log/"
            payload = json.dumps(data_set)
            headers = {
              'Content-Type': 'application/json'
            }
            response = requests.request("POST", url, headers=headers, data=payload)
            print(response.text)
    except Exception as e:
       logger.error('error enviando los datos NOC :'+str(e))
       
def send_warnings(alertType, message):
    try:
        global ipXtamCentral
        global ipXtamRemote
        print(ipXtamCentral)
        url = "http://"+ipXtamCentral+":3000/api/xtamAlerts/setWarnings/"
        payload = json.dumps({
          "ip": ipXtamRemote,
          "alert": alertType,
          "description": message
        })
        headers = {
            'Content-Type': 'application/json'
        }
        response = requests.request("POST", url, headers=headers, data=payload)
        print(response.text)
        
    except Exception as e:
        print(e)
        logger.error('error enviando los datos NOC :'+str(e))

def update_noc ():
    try:
        global count_alert_cpu
        global count_alert_temp
        global count_alert_robustel
        global count_alert_disk
        global ipXtamRemote
        
        average_cpu = 0
        data_set = {"ipXtam": ipXtamRemote,"used_disk1":"0", "used_disk2":"0", "used_ram":"0", "used_cpu":"0", "temperature":"0","robustel":"lost","uptime":"0","minutes":"0"}       
        
        #leer json de promedio de consumo
        if(check_File_Exist('/var/www/html/Api/Monitor/average_consuption.json')):
            #Valores maximos parametrizables
            with open('/home/pi/XtamLite/maxValues.txt') as file:
                new_data = json.load(file)
                file.close()
                maxDisk = new_data['maxValues']['Disk']
                maxTemp = new_data['maxValues']['Temperature']
                maxCpu  = new_data['maxValues']['Cpu']
                maxRam  = new_data['maxValues']['Ram']
            #leer ultimo consumo desde API/NOC    
            with open('/var/www/html/Api/new.json') as file:
                new_data = json.load(file)
                file.close()
                #promedio cpu en los 4 nucleos
                for cpus in new_data['cpu']:                 
                    average_cpu = (average_cpu + float(new_data['cpu'][cpus]['Load']))/2
                
            with open('/var/www/html/Api/Monitor/average_consuption.json') as file:                
                last_data = json.load(file)
                file.close()
                
                data_set['used_disk1'] = round(float(new_data['disco']['1']['Percent']),2)
                data_set['used_ram']   = round((float(last_data['used_ram'])   + float(new_data['memoria']['Porcent']))/2,2)
                data_set['used_cpu']   = round((float(last_data['used_cpu'])   + float(average_cpu))/2 ,2)             
                data_set['temperature']= round((float(last_data['temperature'])+ float(new_data['temperature']))/2 , 2)               
                data_set['uptime']     = new_data['time']
                data_set['minutes']    = int(last_data['minutes']) + 1
                print(data_set)
                
                #Alertas
                if data_set['used_disk1'] >= maxDisk:
                    loggerWarning.info(f"Disco por encima de %i porciento'" % data_set['used_disk1'])
                    #control saturacion de alertas solo envia 1 cada 30 minutos                                      
                    if count_alert_disk == 1:  
                        disk_message = 'disco por encima de %i porciento' % data_set['used_disk1']
                        send_warnings('disk',  disk_message)                        
                    else :
                       if(count_alert_disk == 60):
                           count_alert_disk = 0
                    count_alert_disk += 1
                else:
                    count_alert_disk = 0
                    
                if data_set['used_cpu'] >= maxCpu:
                    loggerWarning.info(f"dpu elevada %i" % data_set['used_cpu'])
                    #control saturacion de alertas solo envia 1 cada 30 minutos                                      
                    if count_alert_cpu == 1:                       
                        cpu_message = 'cpu por encima de %i porciento' % data_set['used_cpu']
                        send_warnings('cpu',  cpu_message)                        
                    else :
                       if(count_alert_cpu == 60):
                           count_alert_cpu = 0
                    count_alert_cpu += 1
                else:
                    count_alert_cpu = 0
                     
                if float(new_data['temperature']) >= maxTemp:
                    #print(f"Temperatura elevada por encima de los %i °C" % float(new_data['temperature']))
                    loggerWarning.info(f"Temperatura elevada por encima de los %f °C" % float(new_data['temperature']))
                    #control saturacion de alertas solo envia 1 cada 30 minutos                                      
                    if count_alert_temp == 1:
                        temp_message = 'Temperatura por encima de %i °C' % data_set['temperature']
                        send_warnings('temperature',  temp_message)                        
                    else :
                       if(count_alert_temp == 60):
                           count_alert_temp = 0
                    count_alert_temp += 1
                else:
                    count_alert_temp = 0
                '''               
                if new_data['robustel']== "lost":
                    #print("Robustel sin señal")
                    loggerWarning.info("Robustel sin señal")
                    #control saturacion de alertas solo envia 1 cada 30 minutos 
                    if count_alert_robustel == 1:
                        robust_message = 'Robustel sin señal'
                        send_warnings('robustel',  robust_message)                        
                    else :
                       if(count_alert_robustel == 60):
                           count_alert_robustel = 0
                    count_alert_robustel += 1
                else:
                    count_alert_robustel = 0
				'''
                #termina alertas        
                if data_set['minutes'] == 60:
                    logger.info(data_set)
                    print('enviar peticion average')
                    send_average_consumption()
                    data_set['minutes']= 0
                    count_alert_cpu = 0
                    count_alert_robustel = 0
                    count_alert_temp = 0
                with open('/var/www/html/Api/Monitor/average_consuption.json', 'w') as file:
                    json.dump(data_set, file)
                    print('promedio actualizado')
                    file.close()
        else:
            print('no existe')
            with open('/var/www/html/Api/new.json', 'r') as nocfile:
                data = json.load(nocfile)
                ipXtam = data['xtam']['Ip']
                used_disk1 = data['disco']['1']['Percent']
                used_ram   = data['memoria']['Porcent']
                uptime     = data['time']
                robustel   = data['robustel']
                for cpus in data['cpu']:
                    print(data['cpu'][cpus]['Load'])
                    #promedio cpu
                    average_cpu = (average_cpu + float(data['cpu'][cpus]['Load']))/2
                print('average',average_cpu)
                temperature= data['temperature']
                nocfile.close()
            ##crear json nuevo
            data_set = {"ipXtam":ipXtam,"used_disk1":used_disk1, "used_disk2":"0", "used_ram":used_ram, "used_cpu":average_cpu, "temperature":temperature, "uptime":uptime ,"robustel":robustel,"minutes":"0"}
             
            with open('/var/www/html/Api/Monitor/average_consuption.json', 'w') as file:
                json.dump(data_set, file)
                file.close()
            
    except Exception as e:
        print(e)
        logger.error('error actualizando los datos NOC :'+str(e)) 

while True :
    try:
        update_noc() 
        time.sleep(30) 
    except:
        logger.info("Error inesperado:",sys.exc_info()[0])       
        time.sleep(30)
