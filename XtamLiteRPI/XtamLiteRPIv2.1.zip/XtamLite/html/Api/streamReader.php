<?php 

if(!empty($_POST['camera']) && !empty($_POST['status'])) {

    //reade json file
    $file = file_get_contents("stream.json");
    $json_a = json_decode($file, true);
    
    $json_a[$_POST['camera']] = $_POST['status'];
    $newJsonString = json_encode($json_a);
    file_put_contents('stream.json', $newJsonString);
    echo json_encode($json_a);
}else{
    http_response_code(400);
}

?>

